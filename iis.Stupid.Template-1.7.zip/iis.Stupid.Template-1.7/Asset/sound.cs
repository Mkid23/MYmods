﻿using UnityEngine;
using UnityEngine.XR;

public class PlaySoundOnXPress : MonoBehaviour
{
    private AudioSource audioSource;
    private AudioClip clip;
    private InputDevice leftHandDevice;

    private bool wasPressedLastFrame = false;

    void Start()
    {
        // Load the sound from Resources folder (without extension)
        clip = Resources.Load<AudioClip>("UntitledMenu_untitled_Assets_menuclose");
        if (clip == null)
        {
            Debug.LogError("failed.wav");
            return;
        }

        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.clip = clip;
    }

    void Update()
    {
        if (!leftHandDevice.isValid)
        {
            leftHandDevice = InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
        }

        bool xPressed = false;
        if (leftHandDevice.TryGetFeatureValue(CommonUsages.primaryButton, out xPressed) && xPressed)
        {
            if (!wasPressedLastFrame)  // Trigger once on button down
            {
                if (!audioSource.isPlaying)
                    audioSource.Play();
            }
        }

        wasPressedLastFrame = xPressed;
    }
}
