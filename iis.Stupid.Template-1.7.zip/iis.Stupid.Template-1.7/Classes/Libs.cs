﻿using BepInEx;
using GorillaLocomotion;
using StupidTemplate;
using System;
using UnityEngine;
using UnityEngine.XR;

namespace untitled.Libs
{
    internal class GunLib
    {
        public static void GunCleanUp()
        {
            bool flag = GunLib.pointer == null || GunLib.lr == null;
            if (!flag)
            {
                UnityEngine.Object.Destroy(GunLib.pointer);
                GunLib.pointer = null;
                UnityEngine.Object.Destroy(GunLib.lr.gameObject);
                GunLib.lr = null;
                GunLib.data = new GunLib.GunLibData(false, false, false, null, default(Vector3), default(RaycastHit));
            }
        }

        public static GunLib.GunLibData ShootLock()
        {
            GunLib.GunLibData result;
            try
            {
                bool isDeviceActive = XRSettings.isDeviceActive;
                if (isDeviceActive)
                {
                    bool flag = false;
                    bool flag2 = !flag;
                    Transform transform;
                    if (flag2)
                    {
                        transform = GTPlayer.Instance.rightControllerTransform;
                        GunLib.data.isShooting = ControllerInputPoller.instance.rightGrab;
                        GunLib.data.isTriggered = (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f);
                    }
                    else
                    {
                        transform = GTPlayer.Instance.leftControllerTransform;
                        GunLib.data.isShooting = ControllerInputPoller.instance.leftGrab;
                        GunLib.data.isTriggered = (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f);
                    }
                    bool isShooting = GunLib.data.isShooting;
                    if (isShooting)
                    {
                        Renderer renderer = (GunLib.pointer != null) ? GunLib.pointer.GetComponent<Renderer>() : null;
                        bool flag3 = GunLib.data.lockedPlayer == null && !GunLib.data.isLocked;
                        if (flag3)
                        {
                            RaycastHit raycastHit;
                            bool flag4 = Physics.Raycast(transform.position - transform.up, -transform.up, out raycastHit) && GunLib.pointer == null;
                            if (flag4)
                            {
                                GunLib.pointer = GameObject.CreatePrimitive(0);
                                UnityEngine.Object.Destroy(GunLib.pointer.GetComponent<Rigidbody>());
                                UnityEngine.Object.Destroy(GunLib.pointer.GetComponent<SphereCollider>());
                                GunLib.pointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                                renderer = GunLib.pointer.GetComponent<Renderer>();
                                renderer.material.color = Color.blue;
                                renderer.material.shader = Shader.Find("GUI/Text Shader");
                            }
                            if (Settings.GunLine)
                            {
                                if (GunLib.lr == null)
                                {
                                    GameObject gameObject = new GameObject("line");
                                    GunLib.lr = gameObject.AddComponent<LineRenderer>();
                                    GunLib.lr.endWidth = 0.01f;
                                    GunLib.lr.startWidth = 0.01f;
                                    GunLib.lr.material.shader = Shader.Find("GUI/Text Shader");
                                }
                                GunLib.lr.SetPosition(0, transform.position);
                                GunLib.lr.SetPosition(1, raycastHit.point);
                            }
                            GunLib.data.hitPosition = raycastHit.point;
                            GunLib.pointer.transform.position = raycastHit.point;
                            VRRig componentInParent = raycastHit.collider.GetComponentInParent<VRRig>();
                            if (componentInParent != null)
                            {
                                if (GunLib.data.isTriggered)
                                {
                                    GunLib.data.lockedPlayer = componentInParent;
                                    GunLib.data.isLocked = true;
                                    if (Settings.GunLine)
                                    {
                                        GunLib.lr.startColor = Color.blue;
                                        GunLib.lr.endColor = Color.blue;
                                    }
                                    renderer.material.color = Color.blue;
                                }
                                else
                                {
                                    GunLib.data.isLocked = false;
                                    if (Settings.GunLine)
                                    {
                                        GunLib.lr.startColor = Color.green;
                                        GunLib.lr.endColor = Color.green;
                                    }
                                    renderer.material.color = Color.green;
                                    GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tagHapticStrength / 2f, GorillaTagger.Instance.tagHapticDuration / 2f);
                                }
                            }
                            else
                            {
                                GunLib.data.isLocked = false;
                                if (Settings.GunLine)
                                {
                                    GunLib.lr.startColor = Color.blue;
                                    GunLib.lr.endColor = Color.blue;
                                }
                                renderer.material.color = Color.blue;
                            }
                        }

                        if (GunLib.data.isTriggered && GunLib.data.lockedPlayer != null)
                        {
                            GunLib.data.isLocked = true;
                            if (Settings.GunLine)
                            {
                                GunLib.lr.SetPosition(0, transform.position);
                                GunLib.lr.SetPosition(1, GunLib.data.lockedPlayer.transform.position);
                                GunLib.lr.startColor = Color.blue;
                                GunLib.lr.endColor = Color.blue;
                            }
                            GunLib.data.hitPosition = GunLib.data.lockedPlayer.transform.position;
                            GunLib.pointer.transform.position = GunLib.data.lockedPlayer.transform.position;
                            renderer.material.color = Color.blue;
                        }
                        else if (GunLib.data.lockedPlayer != null)
                        {
                            GunLib.data.isLocked = false;
                            GunLib.data.lockedPlayer = null;
                            if (Settings.GunLine)
                            {
                                GunLib.lr.startColor = Color.blue;
                                GunLib.lr.endColor = Color.blue;
                            }
                            renderer.material.color = Color.blue;
                        }
                    }
                    else
                    {
                        GunLib.GunCleanUp();
                    }
                    result = GunLib.data;
                }
                else
                {
                    // Non-VR fallback omitted for brevity (same fixes apply)
                    GunLib.data.isShooting = false;
                    result = GunLib.data;
                }
            }
            catch (Exception ex)
            {
                Debug.Log(ex.ToString());
                result = null;
            }
            return result;
        }

        // Other methods omitted for brevity (apply same fixes)

        private static GameObject pointer;
        private static LineRenderer lr;
        private static GunLib.GunLibData data = new GunLib.GunLibData(false, false, false, null, default(Vector3), default(RaycastHit));

        public class GunLibData
        {
            public VRRig lockedPlayer { get; set; }
            public bool isShooting { get; set; }
            public bool isLocked { get; set; }
            public Vector3 hitPosition { get; set; }
            public GameObject hitPointer { get; set; }
            public RaycastHit RaycastHit { get; set; }
            public bool isTriggered { get; set; }

            public GunLibData(bool stateTriggered, bool triggy, bool foundPlayer, VRRig player = null, Vector3 hitpos = default(Vector3), RaycastHit raycastHit = default(RaycastHit))
            {
                this.lockedPlayer = player;
                this.isShooting = stateTriggered;
                this.isLocked = foundPlayer;
                this.hitPosition = hitpos;
                this.isTriggered = triggy;
                this.RaycastHit = raycastHit;
            }
        }
    }

    // Add this temporary class to fix missing reference (replace with your actual Settings)
    public static class Settings
    {
        public static bool GunLine = true;
    }
}
