﻿using UnityEngine;

public class BuilderTableNetworking : MonoBehaviour
{
    public static BuilderTableNetworking instance;

    private void Awake()
    {
        instance = this;
    }
}
