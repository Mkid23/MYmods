﻿using BepInEx;
using Photon.Pun;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using UnityEngine;

namespace GorillaTagMods
{
    public class Main2 : BaseUnityPlugin
    {
        public static void RPCProtection()
        {
            try
            {
                if (!Main.hasRemovedThisFrame)
                {
                    if (Main.NoOverlapRPCs)
                    {
                        Main.hasRemovedThisFrame = true;
                    }
                    GorillaNot.instance.rpcErrorMax = int.MaxValue;
                    GorillaNot.instance.rpcCallLimit = int.MaxValue;
                    GorillaNot.instance.logErrorMax = int.MaxValue;
                    PhotonNetwork.MaxResendsBeforeDisconnect = int.MaxValue;
                    PhotonNetwork.QuickResends = int.MaxValue;
                    PhotonNetwork.SendAllOutgoingCommands();
                }
            }
            catch
            {
                Debug.Log("RPC protection failed, are you in a lobby?");
            }
        }
    }
}

