﻿using GorillaTagScripts;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using untitled.Libs;

namespace untitled.Cheat
{
    public static class Gamemode
    {
        public static void TagGun()
        {
            GunLib.GunLibData gunLibData = GunLib.ShootLock();
            if (gunLibData.isShooting && gunLibData.isTriggered && gunLibData.lockedPlayer != null)
            {
                TagPlayer(gunLibData.lockedPlayer);
            }
        }

        public static void TagPlayer(VRRig plr)
        {
            if (PhotonNetwork.IsMasterClient)
            {
                Master.TagPlayer(plr.Creator.ActorNumber);
            }
            else
            {
                if (GorillaTagger.Instance.offlineVRRig != null && !GorillaTagger.Instance.offlineVRRig.enabled)
                    return;

                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = plr.transform.position + new Vector3(0f, -0.2f, 0f);
                Master.Serialize();

                PhotonView photonView = PunExtensions.GetPhotonView(GameObject.Find("Player Objects/RigCache/Network Parent/GameMode(Clone)"));
                if (photonView != null)
                {
                    photonView.RPC("RPC_ReportTag", RpcTarget.All, new object[]
                    {
                        plr.Creator.ActorNumber
                    });
                }

                GorillaTagger.Instance.offlineVRRig.enabled = true;
                Master.Serialize();
            }
        }
    }

    // Minimal stub of Master class just for TagGun to work
    public static class Master
    {
        public static bool IsMasterClient => PhotonNetwork.IsMasterClient;

        public static void TagPlayer(int actorNumber)
        {
            // Replace with your logic to tag a player by ActorNumber
            Debug.Log($"[Master] Tagging player with ActorNumber: {actorNumber}");
        }

        public static void Serialize()
        {
            // Implement serialization logic here if needed
        }
    }
}
