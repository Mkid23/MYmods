﻿using GorillaLocomotion;
using GorillaNetworking;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using Photon.Voice.Unity;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace PortGT_lite.Classes
{
    // Token: 0x02000068 RID: 104
    public class Safety
    {
        public static void AntiReport()
        {
            foreach (GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
            {
                bool flag = gorillaPlayerScoreboardLine.linePlayer == NetworkSystem.Instance.LocalPlayer;
                if (flag)
                {
                    foreach (VRRig vrrig in RigShit.GetAllRigs(false))
                    {
                        Vector3 position = gorillaPlayerScoreboardLine.reportButton.gameObject.transform.position;
                        float num = 0.355f;
                        bool flag2 = Vector3.Distance(vrrig.rightHandTransform.position, position) < num || Vector3.Distance(vrrig.leftHandTransform.position, position) < num;
                        if (flag2)
                        {
                            PhotonNetwork.Disconnect();
                        }
                    }
                }
            }
        }
    }

            internal class RigShit : MonoBehaviour
            {

                public static VRRig GetVRRigFromPlayer(Player p)
                {
                    return GorillaGameManager.instance.FindPlayerVRRig(p);
                }

                public static List<VRRig> GetAllRigs(bool i = true)
                {
                    return i ? GorillaParent.instance.vrrigs : GetOtherRigs();
                }
                public static List<VRRig> GetOtherRigs()
                {
                    List<VRRig> list = new List<VRRig>();
                    foreach (VRRig vrrig in GetAllRigs(true))
                    {
                        bool flag = !vrrig.isOfflineVRRig && !list.Contains(vrrig);
                        if (flag)
                        {
                            list.Add(vrrig);
                        }
                    }
                    return list;
                }
                public static Player GetPlayerFromVRRig(VRRig p)
                {
                    return p.Creator.GetPlayerRef();
                }

                public static NetworkView GetNetworkFromRig(VRRig r)
                {
                    return (NetworkView)Traverse.Create(r).Field("netView").GetValue();
                }
                public static VRRig GetOwnRig()
                {
                    return VRRig.LocalRig;
                }

                public static VRRig GetRandomRig(bool s)
                {
                    List<VRRig> list = new List<VRRig>();
                    foreach (VRRig vrrig in GetAllRigs(true))
                    {
                        if (s)
                        {
                            bool flag = !list.Contains(vrrig);
                            if (flag)
                            {
                                list.Add(vrrig);
                            }
                        }
                        else
                        {
                            bool flag2 = !vrrig.isOfflineVRRig;
                            if (flag2)
                            {
                                bool flag3 = !list.Contains(vrrig);
                                if (flag3)
                                {
                                    list.Add(vrrig);
                                }
                            }
                        }
                    }
                    random++;
                    bool flag4 = random > list.Count;
                    if (flag4)
                    {
                        random = 0;
                    }
                    return list[random];
                }

                public static int random;
            }
        }
