﻿using ExitGames.Client.Photon;
using GorillaLocomotion;
using GorillaNetworking;
using GorillaTagScripts;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using PortGTlite.Utilities;
using StupidTemplate.Mods;
using StupidTemplate.Notifications;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.XR;
using untitled.Libs;


namespace untitled.Cheat
{
    public class Overpowered : MonoBehaviour
    {
        public static string CurrentQueue
        {
            get
            {
                string text = (string)PhotonNetwork.CurrentRoom.CustomProperties["gameMode"];
                if (text.Contains("DEFAULT")) return "DEFAULT";
                if (text.Contains("MINIGAMES")) return "MINIGAMES";
                if (text.Contains("COMPTITIVE")) return "COMPTITIVE";
                return "DEFAULT";
            }
        }

        public static string CurrentMode
        {
            get
            {
                string text = (string)PhotonNetwork.CurrentRoom.CustomProperties["gameMode"];
                if (text.Contains("Infection")) return "Infection";
                if (text.Contains("Guardian")) return "Guardian";
                if (text.Contains("Casual")) return "Casual";
                if (text.Contains("Freezetag")) return "Freezetag";
                return "Freezetag";
            }
        }

        public static IEnumerator KickPlayer(Player Target)
        {
            Traverse.Create(GameObject.Find("PhotonMono").GetComponent<PhotonHandler>())
                .Field("nextSendTickCountOnSerialize").SetValue((int)(Time.realtimeSinceStartup * 9999f));
            yield return new WaitForSeconds(0.5f);

            for (int i = 0; i < 3960; i++)
            {
                PhotonView pv = FriendshipGroupDetection.Instance.photonView;

                ExitGames.Client.Photon.Hashtable hashtable = new ExitGames.Client.Photon.Hashtable
                {
                    { 0, pv.ViewID },
                    { 2, PhotonNetwork.ServerTimestamp + -2147483647 },
                    { 3, "VerifyPartyMember" },
                    { 5, 70 }
                };

                RaiseEventOptions raiseEventOptions = new RaiseEventOptions
                {
                    TargetActors = new int[] { Target.ActorNumber },
                    InterestGroup = pv.Group
                };

                SendOptions sendOptions = new SendOptions
                {
                    Reliability = true,
                    DeliveryMode = DeliveryMode.Reliable, // Fixed!
                    Encrypt = false
                };

                PhotonNetwork.NetworkingClient.LoadBalancingPeer.OpRaiseEvent(200, hashtable, raiseEventOptions, sendOptions);
            }
        }

        public static void SetTick(float tick)
        {
            Traverse.Create(GameObject.Find("PhotonMono").GetComponent<PhotonHandler>())
                .Field("nextSendTickCountOnSerialize").SetValue((int)(Time.realtimeSinceStartup * tick));
        }

        public static void test()
        {
            GunLib.GunLibData gunLibData = GunLib.ShootLock();
            if (gunLibData.isShooting && gunLibData.isTriggered)
            {
                Global.done = !Global.done;
                Dictionary<byte, object> dictionary = new Dictionary<byte, object>();
                ExitGames.Client.Photon.Hashtable hashtable = new ExitGames.Client.Photon.Hashtable
                {
                    { "didTutorial", float.NaN }
                };

                dictionary.Add(251, hashtable);
                dictionary.Add(250, true);
                dictionary.Add(254, gunLibData.lockedPlayer.Creator.ActorNumber);

                PhotonNetwork.NetworkingClient.LoadBalancingPeer.SendOperation(252, dictionary, SendOptions.SendReliable);
            }
        }

        public static void KickGun()
        {
            GunLib.GunLibData gunLibData = GunLib.ShootLock();
            if (gunLibData.isShooting && gunLibData.isTriggered)
            {
                SetTick(9999f);
                if (kick == null)
                {
                    kick = BuilderTableNetworking.instance.StartCoroutine(KickPlayer(gunLibData.lockedPlayer.Creator.GetPlayerRef()));
                    PhotonNetwork.SendAllOutgoingCommands();
                }
            }
            else if (kick != null)
            {
                SetTick(1000f);
                BuilderTableNetworking.instance.StopCoroutine(kick);
                kick = null;
            }
        }


        public static void ScareGun()
        {
            GunLib.GunLibData gunLibData = GunLib.ShootLock();
            bool flag = gunLibData.isShooting && gunLibData.isTriggered;
            if (flag)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = gunLibData.hitPosition;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }

        public static GameObject ray;
        public static bool timeout;
        public static float cooldown;
        public static float cooldown2;
        public static float flint;
        public static int counter;
        public static int countercams;
        public static int countercamsdih;
        public static List<GameObject> cams = new List<GameObject>();
        public static List<GameObject> camsdih = new List<GameObject>();
        public static Coroutine kick = null;
        public static Coroutine crash = null;

        public static void SetNetStatus(int state, RaiseEventOptions balls)
        {
            object[] array = new object[]
            {
                state
            };
            PhotonNetwork.RaiseEvent(3, new object[]
            {
                PhotonNetwork.ServerTimestamp,
                2,
                array
            }, balls, SendOptions.SendUnreliable);
        }
        public static void ViberateGun()
        {
            bool isMasterClient = Master.IsMasterClient;
            if (isMasterClient)
            {
                GunLib.GunLibData gunLibData = GunLib.ShootLock();
                bool flag = gunLibData.isShooting && gunLibData.isTriggered && gunLibData.isLocked;
                if (flag)
                {
                    bool flag2 = Overpowered.MasterClientTimedAction < Time.time;
                    if (flag2)
                    {
                        Overpowered.MasterClientTimedAction = Time.time + 0.2f;
                        Overpowered.SetNetStatus(1, new RaiseEventOptions
                        {
                            TargetActors = new int[]
                            {
                                gunLibData.lockedPlayer.Creator.ActorNumber
                            }
                        });

                    }
                }
            }
        }
        public static float MasterClientTimedAction;


        public static float Cooldown;

        public static void FreezeRigGun(bool all)
        {
            GunLib.GunLibData gunLibData = GunLib.ShootLock();
            bool flag = gunLibData.isShooting && gunLibData.isTriggered && Time.time > cooldown;

            if (flag)
            {
                List<int> list = new List<int>();

                foreach (Player player in PhotonNetwork.PlayerListOthers)
                {
                    bool flag2 = player == gunLibData.lockedPlayer.Creator.GetPlayerRef();
                    if (flag2)
                    {
                        list.Add(player.ActorNumber);
                    }
                }

                LoadBalancingClient networkingClient = PhotonNetwork.NetworkingClient;
                byte b = 242;

                var hashtable = new ExitGames.Client.Photon.Hashtable
            {
                { 0, "Player Network Controller" },
                { 6, PhotonNetwork.ServerTimestamp },
                { 4, new int[] { } },
                { 7, GetPv(gunLibData.lockedPlayer).ViewID },
                { 8, GetPv(gunLibData.lockedPlayer).ViewID }
            };

                RaiseEventOptions raiseOptions = new RaiseEventOptions
                {
                    TargetActors = list.ToArray(),
                    Receivers = ReceiverGroup.Others
                };

                SendOptions sendOptions = new SendOptions
                {
                    Reliability = true
                };

                networkingClient.OpRaiseEvent(b, hashtable, raiseOptions, sendOptions);

                if (all)
                {
                    PhotonNetwork.RemoveInstantiatedGO(GetPv(gunLibData.lockedPlayer).gameObject, true);
                }

                cooldown = Time.time + 0.5f;
            }
        }

        // ✅ Helper to get PhotonView
        public static PhotonView GetPv(VRRig rig)
        {
            return rig?.gameObject?.GetComponent<PhotonView>();
        }

        public static void RGBMonkey()
        {
            float num = Time.time * 0.7f;
            float num2 = Mathf.Sin(num) * 0.5f + 0.5f;
            float num3 = Mathf.Sin(num + 2.0943952f) * 0.5f + 0.5f;
            float num4 = Mathf.Sin(num + 4.1887903f) * 0.5f + 0.5f;
            GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", 0, new object[]
            {
                num2,
                num3,
                num4
            });
        }

        public static void CrashGun(float delay, int foramount)
        {
            GunLib.GunLibData gunLibData = GunLib.ShootLock();
            bool flag = gunLibData.isShooting && gunLibData.isTriggered;
            if (flag)
            {
                bool flag2 = Time.time > Overpowered.cooldown;
                if (flag2)
                {
                    Overpowered.cooldown = Time.time + delay;
                    for (int i = 0; i < foramount; i++)
                    {
                        PhotonNetwork.NetworkingClient.OpRaiseEvent(204, new object[]
                        {

                        }, new RaiseEventOptions
                        {
                            CachingOption = 0,
                            TargetActors = new int[]
                            {
                                gunLibData.lockedPlayer.Creator.ActorNumber
                            }
                        }, SendOptions.SendReliable);
                    }
                }


            }

        }
        public static void LowGravity()
        {
            Overpowered.taggerInstance.AddForce(Vector3.up * 6.5f, ForceMode.Impulse);
        }

        public static void AntiGravity()
        {
            Overpowered.taggerInstance.AddForce(Vector3.up * 8f, ForceMode.Impulse);
        }

        public static void HighGravity()
        {
            Overpowered.taggerInstance.AddForce(Vector3.down * 8f, ForceMode.Impulse);
        }

        public static void ReverseGravity()
        {
            Overpowered.taggerInstance.AddForce(Vector3.up * 19.62f, ForceMode.Impulse);
        }


        public static VRRig playerInstance = new GameObject("Player").AddComponent<VRRig>();

        // ✅ ADD THIS LINE ↓
        public static Rigidbody taggerInstance = new GameObject("Tagger").AddComponent<Rigidbody>();

        


        public static void WatersplashGun()
        {
            GunLib.GunLibData gunLibData = GunLib.ShootLock();
            bool flag = gunLibData.isShooting && gunLibData.isTriggered;
            if (flag)
            {
                Overpowered.NetworkSplash(gunLibData.hitPosition, Quaternion.identity, 1f, true, 0.1f);
            }
        }
        public static void WatersplashHands()
        {
            bool rightGrab = ControllerInputPoller.instance.rightGrab;
            if (rightGrab)
            {
                Overpowered.NetworkSplash(Overpowered.TrueRightHand().Item1, Overpowered.TrueLeftHand().Item2, 1f, true, 0.1f);
            }
            bool leftGrab = ControllerInputPoller.instance.leftGrab;
            if (leftGrab)
            {
                Overpowered.NetworkSplash(Overpowered.TrueLeftHand().Item1, Overpowered.TrueLeftHand().Item2, 1f, true, 0.1f);
            }
        }
        public static ValueTuple<Vector3, Quaternion, Vector3, Vector3, Vector3> TrueRightHand()
        {
            Quaternion quaternion = GorillaTagger.Instance.rightHandTransform.rotation * GTPlayer.Instance.rightHandRotOffset;
            return new ValueTuple<Vector3, Quaternion, Vector3, Vector3, Vector3>(GorillaTagger.Instance.rightHandTransform.position + GorillaTagger.Instance.rightHandTransform.rotation * GTPlayer.Instance.rightHandOffset, quaternion, quaternion * Vector3.up, quaternion * Vector3.forward, quaternion * Vector3.right);
        }
        public static ValueTuple<Vector3, Quaternion, Vector3, Vector3, Vector3> TrueLeftHand()
        {
            Quaternion quaternion = GorillaTagger.Instance.leftHandTransform.rotation * GTPlayer.Instance.leftHandRotOffset;
            return new ValueTuple<Vector3, Quaternion, Vector3, Vector3, Vector3>(GorillaTagger.Instance.leftHandTransform.position + GorillaTagger.Instance.leftHandTransform.rotation * GTPlayer.Instance.leftHandOffset, quaternion, quaternion * Vector3.up, quaternion * Vector3.forward, quaternion * Vector3.right);
        }

        // ProcessedBy_MiDeobf_Engine_b3.2.r3 RVA: 0x0000F8A8
        public static void NetworkSplash(Vector3 position, Quaternion rotation, float size, bool bigSplash, float timeCooldown)
        {
            bool flag = Global.SplashCooldown < Time.time;
            if (flag)
            {
                Global.SplashCooldown = Time.time + timeCooldown;
                GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", 0, new object[]
                {
                    position,
                    rotation,
                    size,
                    size,
                    bigSplash,
                    bigSplash
                });
            }
        }
        //                new ButtonInfo { buttonText = "WatersplashHands", method = () => overpowered.WatersplashHands(), isTogglable = true }
        //                new ButtonInfo { buttonText = "WatersplashGun", method = () => overpowered.WatersplashGun(), isTogglable = true }

    }
            

}
