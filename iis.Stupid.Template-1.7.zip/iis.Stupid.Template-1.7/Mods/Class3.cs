﻿using GorillaLocomotion;
using GorillaTagMods;
using StupidTemplate.Menu;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Windows;
using UnityEngine.XR;

namespace StupidTemplate.Mods
{
    internal class Class3
    {
        public static void PunchMod()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                bool flag = vrrig != GorillaTagger.Instance.offlineVRRig;
                bool flag2 = flag;
                if (flag2)
                {
                    float num = Vector3.Distance(vrrig.rightHandTransform.position, GorillaTagger.Instance.offlineVRRig.bodyTransform.position);
                    float num2 = Vector3.Distance(vrrig.leftHandTransform.position, GorillaTagger.Instance.offlineVRRig.bodyTransform.position);
                    bool flag3 = num < 0.2f;
                    bool flag4 = flag3;
                    if (flag4)
                    {
                        GTPlayer.Instance.GetComponent<Rigidbody>().velocity += vrrig.rightHandTransform.forward * 10f;
                    }
                    bool flag5 = num2 < 0.2f;
                    bool flag6 = flag5;
                    if (flag6)
                    {
                        GTPlayer.Instance.GetComponent<Rigidbody>().velocity += vrrig.leftHandTransform.forward * 10f;
                    }
                }
            }
        }
        public static void HelicopterMonke()
        {
            bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f;
            bool flag2 = flag;
            bool flag3 = flag2;
            if (flag3)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = GTPlayer.Instance.bodyCollider.transform.position + new Vector3(0f, 0.55f, 0f);
                GorillaTagger.Instance.offlineVRRig.transform.Rotate(new Vector3(0f, 50f, 0f));
                GorillaTagger.Instance.offlineVRRig.transform.localPosition += Time.deltaTime * Vector3.up * 3f;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void TagAura()
        {
            float num = 7f;
            VRRig vrrig = null;
            foreach (VRRig vrrig2 in GorillaParent.instance.vrrigs)
            {
                bool flag = GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") && vrrig2 != GorillaTagger.Instance.offlineVRRig && Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, vrrig2.transform.position) < num && !vrrig2.mainSkin.material.name.Contains("fected");
                bool flag2 = flag;
                if (flag2)
                {
                    num = Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, vrrig2.transform.position) * 7f;
                    vrrig = vrrig2;
                }
            }
            GorillaTagger.Instance.leftHandTransform.position = vrrig.transform.position;
            GorillaTagger.Instance.rightHandTransform.position = vrrig.transform.position;
        }
        public static void TagAll()
        {
            bool flag = false;
            Vector3 position = Vector3.zero;
            VRRig vrrig = null;
            bool flag2 = ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f;
            bool flag3 = flag2;
            bool flag4 = flag3;
            if (flag4)
            {
                foreach (VRRig vrrig2 in GorillaParent.instance.vrrigs)
                {
                    bool flag5 = vrrig2 != GorillaTagger.Instance.offlineVRRig;
                    bool flag6 = flag5;
                    bool flag7 = flag6;
                    if (flag7)
                    {
                        bool flag8 = !vrrig2.mainSkin.material.name.Contains("fected");
                        bool flag9 = flag8;
                        bool flag10 = flag9;
                        if (flag10)
                        {
                            flag = true;
                            vrrig = vrrig2;
                            position = vrrig2.transform.position;
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                        }
                    }
                }
                bool flag11 = flag;
                bool flag12 = flag11;
                bool flag13 = flag12;
                if (flag13)
                {
                    GorillaTagger.Instance.offlineVRRig.transform.position = position;
                    bool flag14 = vrrig != null;
                    bool flag15 = flag14;
                    bool flag16 = flag15;
                    if (flag16)
                    {
                        for (int i = 0; i < 4; i++)
                        {


                        }
                    }
                }
                else
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                    Main2.RPCProtection();
                }
            }
        }
        public static void IronMonke()
        {
            bool leftGrab = ControllerInputPoller.instance.leftGrab;
            if (leftGrab)
            {
                GameObject gameObject1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                UnityEngine.Object.Destroy(gameObject1.GetComponent<Collider>());

                gameObject1.transform.localScale = new Vector3(0.25f, 0.3f, 0.4f);
                gameObject1.transform.position = new Vector3(0f, -0.85f, 0f);
                gameObject1.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;
                gameObject1.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                gameObject1.GetComponent<Renderer>().material.color = new Color32(200, 200, 200, 80);
                UnityEngine.Object.Destroy(gameObject1, 0.3f);

            }
            bool leftGrab2 = ControllerInputPoller.instance.leftGrab;
            if (leftGrab2)
            {
                GameObject gameObject1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                UnityEngine.Object.Destroy(gameObject1.GetComponent<Collider>());

                gameObject1.transform.localScale = new Vector3(0.25f, 0.3f, 0.4f);
                gameObject1.transform.position = new Vector3(0f, -0.85f, 0f);
                gameObject1.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;
                gameObject1.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                gameObject1.GetComponent<Renderer>().material.color = new Color32(200, 200, 200, 80);
                UnityEngine.Object.Destroy(gameObject1, 0.3f);

            }
        }
        internal class EditArmLength2
        {

            public static void EditArmLength()
            {
                bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f || Mouse.current.rightButton.isPressed;
                if (flag)
                {
                    EditArmLength2.armlength += 0.001f;
                }
                bool flag2 = ControllerInputPoller.instance.leftControllerIndexFloat > 0.5f || Mouse.current.leftButton.isPressed;
                if (flag2)
                {
                    EditArmLength2.armlength -= 0.001f;
                }
                GTPlayer.Instance.transform.localScale = new Vector3(EditArmLength2.armlength, EditArmLength2.armlength, EditArmLength2.armlength);
            }
            public static float armlength = 1f;
        }
        public static void NoSlippyWalls()
        {
            GTPlayer.Instance.isLeftHandSliding = false;
            GTPlayer.Instance.isRightHandSliding = false;
        }



    }
}