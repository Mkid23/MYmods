﻿using GorillaLocomotion;
using GorillaNetworking;
using GorillaTag.Rendering;
using GorillaTagMods;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Classes;
using System.Reflection;
using UnityEngine; // Add this on top

public class X
{

    public static void DisableFog() =>
        ZoneShaderSettings.activeInstance.SetGroundFogValue(Color.clear, 0f, 0f, 0f);

    public static void EnableFog() =>
        ZoneShaderSettings.activeInstance.SetGroundFogValue(new Color(0.678f, 0.847f, 0.902f, 0.2f), 40f, 10f, 40f);
    public static void FakeUnbanSelf()
    {
        PhotonNetworkController.Instance.UpdateTriggerScreens();
        GorillaScoreboardTotalUpdater.instance.ClearOfflineFailureText();
        GorillaComputer.instance.screenText.DisableFailedState();
        GorillaComputer.instance.functionSelectText.DisableFailedState();
    }
    public static void FixHead()
    {
        VRRig.LocalRig.head.trackingRotationOffset.x = 0f;
        VRRig.LocalRig.head.trackingRotationOffset.y = 0f;
        VRRig.LocalRig.head.trackingRotationOffset.z = 0f;
    }

    public static void UpsideDownHead() =>
        VRRig.LocalRig.head.trackingRotationOffset.z = 180f;

    public static void BrokenNeck() =>
        VRRig.LocalRig.head.trackingRotationOffset.z = 90f;

    public static void BackwardsHead() =>
        VRRig.LocalRig.head.trackingRotationOffset.y = 180f;

    public static void SidewaysHead() =>
        VRRig.LocalRig.head.trackingRotationOffset.y = 90f;


    public static float lastBangTime;
    public static float BPM = 159f;
    public static void HeadBang()
    {
        if (Time.time > lastBangTime)
        {
            VRRig.LocalRig.head.trackingRotationOffset.x = 50f;
            lastBangTime = Time.time + (60f / BPM);
        }
        else
            VRRig.LocalRig.head.trackingRotationOffset.x = Mathf.Lerp(VRRig.LocalRig.head.trackingRotationOffset.x, 0f, 0.1f);
    }

    public static void SpinHead(string axis)
    {
        if (VRRig.LocalRig.enabled)
        {
            switch (axis.ToLower())
            {
                case "x":
                    VRRig.LocalRig.head.trackingRotationOffset.x += 10f;
                    break;
                case "y":
                    VRRig.LocalRig.head.trackingRotationOffset.y += 10f;
                    break;
                case "z":
                    VRRig.LocalRig.head.trackingRotationOffset.z += 10f;
                    break;
                default:
                    return;
            }
        }
        else
            VRRig.LocalRig.head.rigTarget.transform.rotation = Quaternion.Euler(VRRig.LocalRig.head.rigTarget.transform.rotation.eulerAngles + new Vector3(0f, 10f, 0f));
    }



    public static void MuteAll()
    {
        foreach (GorillaPlayerScoreboardLine line in GorillaScoreboardTotalUpdater.allScoreboardLines)
        {
            if (!line.muteButton.isAutoOn)
                line.PressButton(true, GorillaPlayerLineButton.ButtonType.Mute);
        }
    }
    public static void ReportAll()
    {
        foreach (NetPlayer player in NetworkSystem.Instance.PlayerListOthers)
            GorillaPlayerScoreboardLine.ReportPlayer(player.UserId, GorillaPlayerLineButton.ButtonType.Cheating, player.NickName);
    }

}

//new ButtonInfo { buttonText = "DisableFog", method = () => X.DisableFog(), isTogglable = true },
//new ButtonInfo { buttonText = "DisableFog", method = () => X.DisableFog(), isTogglable = true },