﻿using GorillaLocomotion;
using GorillaTagMods;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using System;
using UnityEngine;


namespace StupidTemplate.Mods
{

    internal class Cum
    {
        public static void pee()
        {
            bool rightGrab = ControllerInputPoller.instance.rightGrab;
            if (rightGrab)
            {
                int projHash = -820530352;
                int trailHash = -1;
                Color white = Color.yellow;
                Vector3 position = GTPlayer.Instance.bodyCollider.transform.position;
                Vector3 vel = GTPlayer.Instance.bodyCollider.transform.forward * 8.33f;
                Cum.LaunchProjectile(projHash, trailHash, position, vel, white);
            }
        }
        
        private static float baseHue = 0f;
        public static void rainbowPee()
        {
            bool rightGrab = ControllerInputPoller.instance. leftGrab;
            if (rightGrab)
            {
                int projHash = -820530352;
                int trailHash = -1;
                Color color1 = Color.HSVToRGB(baseHue, 1f, 1f);
                Color color2 = Color.HSVToRGB((baseHue + 0.1f) % 1f, 1f, 1f);
                Vector3 position = GTPlayer.Instance.bodyCollider.transform.position;
                Vector3 vel = GTPlayer.Instance.bodyCollider.transform.forward * 8.33f;
                Cum.LaunchProjectile(projHash, trailHash, position, vel, Color.white);
            }
        }

        // Token: 0x0600005A RID: 90 RVA: 0x000060C4 File Offset: 0x000042C4
        public static void LaunchProjectile(int projHash, int trailHash, Vector3 pos, Vector3 vel, Color col)
        {
            SlingshotProjectile component = ObjectPools.instance.Instantiate(projHash, true).GetComponent<SlingshotProjectile>();
            bool flag = trailHash != -1;
            if (flag)
            {
                SlingshotProjectileTrail component2 = ObjectPools.instance.Instantiate(trailHash, true).GetComponent<SlingshotProjectileTrail>();
                component2.AttachTrail(component.gameObject, false, false);
            }
            int num = 0;
            component.Launch(pos, vel, NetworkSystem.Instance.LocalPlayer, false, false, num++, 1f, true, col);
        }
    }

    internal class Class2
    {
        public static void NightTime()
        {
            BetterDayNightManager.instance.SetTimeOfDay(0);
        }

        // Token: 0x0600009B RID: 155 RVA: 0x00008B14 File Offset: 0x00006D14
        public static void DayTime()
        {
            BetterDayNightManager.instance.SetTimeOfDay(1);
        }
        public static void NoonTime()
        {
            BetterDayNightManager.instance.SetTimeOfDay(5);
        }
        public static void UpsideDownHead()
        {
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 180f;
        }

        public static void FixHead()
        {
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x = 0f;
        }

        internal class ColorShit : MonoBehaviour
        {
            private static Color currentColor = Color.white;
            private static Color targetColor = GetRandomColor();
            private static float lerpTime = 0f;
            private static float duration = 1f; // 1 second per color

            // Call this ONCE to start the fade loop (from your Start or Update manager)
            public static void Init()
            {
                lerpTime = 0f;
                currentColor = targetColor;
                targetColor = GetRandomColor();
            }

            // Call this every frame to update the fading
            public static void Strobe()
            {
                lerpTime += Time.deltaTime;
                float t = Mathf.Clamp01(lerpTime / duration);

                Color newColor = Color.Lerp(currentColor, targetColor, t);
                ChangeColor(newColor);

                if (t >= 1f)
                {
                    // Once fade completes, prepare next target
                    lerpTime = 0f;
                    currentColor = targetColor;
                    targetColor = GetRandomColor();
                }
            }

            private static Color GetRandomColor()
            {
                return new Color(
                    UnityEngine.Random.Range(0f, 1f),
                    UnityEngine.Random.Range(0f, 1f),
                    UnityEngine.Random.Range(0f, 1f),
                    1f
                );
            }
        }
        private static void ChangeColor(Color color)
        {
            

        }

    }
}

