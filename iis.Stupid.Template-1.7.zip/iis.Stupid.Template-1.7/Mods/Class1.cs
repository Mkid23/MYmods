﻿//Tag Gun is in Gamemode.cs
//overpowered has overpowered stuff
//WaterSplashGun
//
//
//
//
//
//
//
//
//
using GorillaExtensions;
using GorillaLocomotion;
using StupidTemplate.Mods;
using UnityEngine;
using UnityEngine.XR;
using untitled.Libs;       // If GunLib is a separate namespace

namespace StupidTemplate
{
    public class Class1
    {

        public static void MoveRigGun()
        {
            GunLib.GunLibData gunLibData = GunLib.ShootLock();
            bool flag = gunLibData.isShooting && gunLibData.isTriggered;
            if (flag)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = gunLibData.hitPosition;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }

        public static void HoldRig()
        {
            bool rightGrip = false;

            // Get the right-hand XR controller
            InputDevice rightHand = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);

            // Try to read the grip button state
            if (rightHand.TryGetFeatureValue(CommonUsages.gripButton, out bool gripValue))
            {
                rightGrip = gripValue;
            }

            if (rightGrip)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = GTPlayer.Instance.rightControllerTransform.position;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }

    }
}

