﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace PortGT_lite.Mods
{
    internal class using_UnityEngine_
    {
public static class HoverboardUtils
    {
            public interface ILocomotionController
            {
                void GrabPersonalHoverboard(bool force, Vector3 position, Quaternion rotation, Color color);
                void SetHoverAllowed(bool allowed, bool force);
                void SetHoverActive(bool active);
            }
            public static void ToggleHoverboard(
            bool enabled,
            GameObject hoverboardVisual,
            ILocomotionController locomotionController,
            System.Func<Color> colorFunc = null
        )
        {
            if (enabled && locomotionController != null)
            {
                locomotionController.GrabPersonalHoverboard(false, new Vector3(0f, 0.2f, 0f), Quaternion.identity, colorFunc?.Invoke() ?? Color.white);
            }

            locomotionController?.SetHoverAllowed(enabled, false);
            locomotionController?.SetHoverActive(enabled);

            if (hoverboardVisual != null)
                hoverboardVisual.SetActive(enabled);
        }
    }

}
}
