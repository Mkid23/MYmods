﻿using BepInEx;
using Photon.Pun;
using System;
using System.Collections.Generic;
using UnityEngine;
using static StupidTemplate.Menu.Main;

namespace StupidTemplate.Mods
{
    internal class Global
    {
        public static void ReturnHome()
        {
            buttonsType = 0;
        }




        public static void SpeedBoost(float speed, float multiplier)
        {
            GorillaLocomotion.GTPlayer.Instance.maxJumpSpeed = speed;
            GorillaLocomotion.GTPlayer.Instance.jumpMultiplier = multiplier;
        }


        public static void fly()
        {
            bool lefttrigger = ControllerInputPoller.instance.leftControllerTriggerButton;
            if (lefttrigger)
            {
                GorillaLocomotion.GTPlayer.Instance.transform.position += (GorillaLocomotion.GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime) * 20;
                GorillaLocomotion.GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
        }

        public static void BoxESP()
        {

            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                {
                    UnityEngine.Color thecolor = vrrig.playerColor;
                    GameObject box = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    box.transform.position = vrrig.transform.position;
                    UnityEngine.Object.Destroy(box.GetComponent<BoxCollider>());
                    box.transform.localScale = new Vector3(0.5f, 0.5f, 0f);
                    box.transform.LookAt(GorillaTagger.Instance.headCollider.transform.position);
                    box.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                    box.GetComponent<Renderer>().material.color = thecolor;
                    UnityEngine.Object.Destroy(box, Time.deltaTime);
                }
            }
        }


        public static bool wait;
        public static GameObject pointer;

        public static void TpGun()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                // Raycast from right controller downwards
                Physics.Raycast(GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position, -GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.up, out var hitInfo);

                // Create pointer if doesn't exist yet
                if (pointer == null)
                {
                    pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);

                    // Remove collider immediately
                    var collider = pointer.GetComponent<Collider>();
                    if (collider != null)
                        GameObject.Destroy(collider);

                    // Remove Rigidbody if any
                    var rb = pointer.GetComponent<Rigidbody>();
                    if (rb != null)
                        GameObject.Destroy(rb);

                    // Set transparent color (alpha 0)
                    pointer.GetComponent<Renderer>().material.color = new Color32(255, 255, 255, 0);
                }

                pointer.transform.position = hitInfo.point;

                if (ControllerInputPoller.instance.rightControllerIndexFloat >= 0.1)
                {
                    if (!wait)
                    {
                        wait = true;
                        GorillaLocomotion.GTPlayer.Instance.transform.position = pointer.transform.position;

                        // Velocity should be a vector, not a position
                        Rigidbody playerRb = GorillaLocomotion.GTPlayer.Instance.GetComponent<Rigidbody>();
                        if (playerRb != null)
                        {
                            playerRb.velocity = Vector3.zero;  // Reset velocity or set to your desired value
                        }
                    }

                    // Destroy pointer after short delay (optional, or keep it visible)
                    GameObject.Destroy(pointer, Time.deltaTime);
                    pointer = null;
                }
                else
                {
                    wait = false;
                }
            }
            else
            {
                // Cleanup pointer if not grabbing
                if (pointer != null)
                {
                    GameObject.Destroy(pointer);
                    pointer = null;
                }
            }
        }





        public static void stickyPlatformsMod()
        {
            if (ControllerInputPoller.instance.leftGrab && leftplats.Count == 0)
            {
                leftplats = CreatePlatformsOnHand(GorillaTagger.Instance.leftHandTransform);
            }

            if (ControllerInputPoller.instance.rightGrab && rightplats.Count == 0)
            {
                rightplats = CreatePlatformsOnHand(GorillaTagger.Instance.rightHandTransform);
            }

            if (ControllerInputPoller.instance.rightGrabRelease && rightplats.Count > 0)
            {
                foreach (var plat in rightplats) GameObject.Destroy(plat);
                rightplats.Clear();
            }

            if (ControllerInputPoller.instance.leftGrabRelease && leftplats.Count > 0)
            {
                foreach (var plat in leftplats) GameObject.Destroy(plat);
                leftplats.Clear();
            }
        }

        private static List<GameObject> leftplats = new List<GameObject>();
        private static List<GameObject> rightplats = new List<GameObject>();

        private static List<GameObject> CreatePlatformsOnHand(Transform handTransform)
        {
            List<GameObject> plats = new List<GameObject>();
            float layerHeight = 0.01f;

            for (int i = 0; i < 5; i++)
            {
                GameObject plat = GameObject.CreatePrimitive(PrimitiveType.Cube);
                plat.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);


                plat.transform.position = handTransform.position + Vector3.up * (i * layerHeight);
                plat.transform.rotation = handTransform.rotation;

                Renderer rend = plat.GetComponent<Renderer>();
                Material mat = new Material(Shader.Find("Unlit/Color"));
                mat.color = Color.red;
                rend.material = mat;

                plats.Add(plat);
            }

            return plats;
        }




        public static bool done = false;

        public static void Ghostmonkey()
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                GameObject lBall = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                lBall.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                lBall.GetComponent<Renderer>().material.color = Color.red;
                lBall.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                lBall.transform.SetParent(GorillaTagger.Instance.leftHandTransform);
                lBall.transform.localPosition = Vector3.zero;

                GameObject rBall = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                rBall.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                rBall.GetComponent<Renderer>().material.color = Color.red;
                rBall.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                rBall.transform.SetParent(GorillaTagger.Instance.rightHandTransform);
                rBall.transform.localPosition = Vector3.zero;

                GorillaTagger.Instance.offlineVRRig.enabled = false;

                UnityEngine.Object.Destroy(rBall, Time.deltaTime);
                UnityEngine.Object.Destroy(lBall, Time.deltaTime);
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }

        public static void SpeeX(float speed, float multiplier)
        {
            GorillaLocomotion.GTPlayer.Instance.maxJumpSpeed = speed;
            GorillaLocomotion.GTPlayer.Instance.jumpMultiplier = multiplier;

        }
        public static float SplashCooldown;
    }

}

