﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class Class4onlyone
    {
        public static void InvisMonke()
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                // Hide all renderers in the VR rig
                SetRigVisibility(false);
            }
            else
            {
                // Show all renderers in the VR rig
                SetRigVisibility(true);
            }
        }

        public static bool isInvisible = false;

        public static void SetRigVisibility(bool isVisible)
        {
            if (GorillaTagger.Instance?.offlineVRRig == null)
                return;

            Renderer[] renderers = GorillaTagger.Instance.offlineVRRig.GetComponentsInChildren<Renderer>(true);
            foreach (Renderer renderer in renderers)
            {
                renderer.enabled = isVisible;
            }
        }



    }
}
