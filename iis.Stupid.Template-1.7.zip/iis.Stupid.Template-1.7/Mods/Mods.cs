﻿using UnityEngine;

public static class FrozoneEffect
{
    public static void Frozone(bool leftGrip, bool rightGrip, Transform leftHand, Transform rightHand, int surfaceIndex = 0)
    {
        if (leftGrip && leftHand != null)
        {
            CreateIceBlock(leftHand, surfaceIndex);
        }

        if (rightGrip && rightHand != null)
        {
            CreateIceBlock(rightHand, surfaceIndex);
        }
    }

    private static void CreateIceBlock(Transform handTransform, int surfaceIndex)
    {
        GameObject iceBlock = GameObject.CreatePrimitive(PrimitiveType.Cube);
        iceBlock.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
        iceBlock.transform.position = handTransform.position + new Vector3(0f, -0.05f, 0f);
        iceBlock.transform.rotation = handTransform.rotation;

        // Optional: Add surface override if needed
        GorillaSurfaceOverride surface = iceBlock.AddComponent<GorillaSurfaceOverride>();
        surface.overrideIndex = surfaceIndex;

        // Set ice color
        Renderer renderer = iceBlock.GetComponent<Renderer>();
        if (renderer != null)
        {
            renderer.material.color = Color.cyan;
        }

        Object.Destroy(iceBlock, 0.3f);
    }
}
