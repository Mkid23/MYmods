﻿using ExitGames.Client.Photon;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using System.Collections.Generic;
using UnityEngine;

namespace PortGTlite.Utilities
{
    // Dummy VRRig class (replace with your real one)
    public class VRRig : MonoBehaviour
    {
        public float scaleMultiplier;
    }

    // Dummy InputHandler class
    public static class InputHandler
    {
        public static bool LSecondary() => Input.GetKeyDown(KeyCode.Z); // example key
        public static bool LTrigger() => Input.GetKey(KeyCode.X);       // example key
        public static bool RTrigger() => Input.GetKey(KeyCode.C);       // example key
    }

    // Dummy Variables class
    public static class Variables
    {
        public static VRRig playerInstance = new GameObject("Player").AddComponent<VRRig>();
    }

    // Static NetworkingLibrary class
    public static class NetworkingLibrary
    {
        public enum NetworkingType
        {
            Size
        }

        private static Dictionary<VRRig, float> receivedScales = new Dictionary<VRRig, float>();

        private static Dictionary<NetworkingType, byte> codeMap = new Dictionary<NetworkingType, byte>
        {
            { NetworkingType.Size, 1 }
        };

        public static void SendNetworkUpdate(NetworkingType type, object[] data, int[] targets = null, bool broadcastToAll = true)
        {
            if (!PhotonNetwork.InRoom || !codeMap.TryGetValue(type, out byte b))
                return;

            RaiseEventOptions receivers = GetReceivers(broadcastToAll, targets);
            SendOptions sendOptions = new SendOptions { Reliability = true };

            PhotonNetwork.NetworkingClient.OpRaiseEvent(b, data, receivers, sendOptions);
        }

        private static RaiseEventOptions GetReceivers(bool broadcastToAll, int[] targets)
        {
            RaiseEventOptions raiseEventOptions = new RaiseEventOptions();

            if (!broadcastToAll && targets != null && targets.Length != 0)
            {
                raiseEventOptions.TargetActors = targets;
                raiseEventOptions.CachingOption = EventCaching.DoNotCache;
            }
            else
            {
                raiseEventOptions.Receivers = ReceiverGroup.All;
                raiseEventOptions.CachingOption = EventCaching.AddToRoomCache;
            }

            return raiseEventOptions;
        }
    }
}

namespace PortGTlite.Mods.Categories
{
    using PortGTlite.Utilities;

    public static class Networked
    {
        public static class SizeChanger
        {
            private static float sizeScale = 1f;
            private static float lastSentScale = 1f;

            public static void NetworkedSizeChanger(bool enable)
            {
                if (!PhotonNetwork.InRoom)
                    return;

                if (enable)
                {
                    if (InputHandler.LSecondary())
                    {
                        sizeScale = 1f;
                    }

                    if (InputHandler.LTrigger())
                    {
                        sizeScale -= 0.05f;
                    }

                    if (InputHandler.RTrigger())
                    {
                        sizeScale += 0.05f;
                    }

                    sizeScale = Mathf.Clamp(sizeScale, 0.375f, 2.75f);
                    Traverse.Create(Variables.playerInstance).Field("scaleMultiplier").SetValue(sizeScale);

                    if (sizeScale != lastSentScale)
                    {
                        lastSentScale = sizeScale;

                        NetworkingLibrary.SendNetworkUpdate(NetworkingLibrary.NetworkingType.Size, new object[]
                        {
                            sizeScale
                        });
                    }
                }
                else
                {
                    NetworkingLibrary.SendNetworkUpdate(NetworkingLibrary.NetworkingType.Size, new object[]
                    {
                        1f
                    });
                }
            }
        }
    }
}
