﻿using Photon.Pun;
using PortGT_lite.Classes;
using PortGTlite.Mods.Categories;
using StupidTemplate.Classes;
using StupidTemplate.Mods;
using UnityEngine;
using untitled.Cheat;
using static PortGT_lite.Mods.using_UnityEngine_;
using static StupidTemplate.Settings;

namespace StupidTemplate.Menu
{
    internal class Buttons
    {
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main Mods
                new ButtonInfo { buttonText = "Disconnect", method = () => Disconnect(), isTogglable = true },
                new ButtonInfo { buttonText = "Menu Settings", method =() => SettingsMods.MenuSettings(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Movement", method =() => SettingsMods.MovementMods(), isTogglable = false, toolTip = "Opens the movement  for the menu."},
                new ButtonInfo { buttonText = "Guns", method =() => SettingsMods.GunMods(), isTogglable = false, toolTip = "Opens the projectile  for the menu."},
                new ButtonInfo { buttonText = "Advantage", method =() => SettingsMods.AdvantageMods(), isTogglable = false, toolTip = "Opens the Advantage  for the menu."},
                new ButtonInfo { buttonText = "Fun", method =() => SettingsMods.FunMods(), isTogglable = false, toolTip = "Opens the Fun for the menu."},
            },

            new ButtonInfo[] { // Menu Settings
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Disconnect", method = () => Disconnect(), isTogglable = true },
                new ButtonInfo { buttonText = "Anti Report", method =() => Safety.AntiReport(), isTogglable = true},
                new ButtonInfo { buttonText = "Right Hand", enableMethod =() => SettingsMods.RightHand(), disableMethod =() => SettingsMods.LeftHand(), toolTip = "Puts the menu on your right hand."},
                new ButtonInfo { buttonText = "Notifications", enableMethod =() => SettingsMods.EnableNotifications(), disableMethod =() => SettingsMods.DisableNotifications(), enabled = !disableNotifications, toolTip = "Toggles the notifications."},
                new ButtonInfo { buttonText = "FPS Counter", enableMethod =() => SettingsMods.EnableFPSCounter(), disableMethod =() => SettingsMods.DisableFPSCounter(), enabled = fpsCounter, toolTip = "Toggles the FPS counter."},
                new ButtonInfo { buttonText = "Toggle Theme", method = () => Settings.ToggleTheme(), isTogglable = false },
                new ButtonInfo { buttonText = "Disconnect Button", enableMethod =() => SettingsMods.EnableDisconnectButton(), disableMethod =() => SettingsMods.DisableDisconnectButton(), enabled = disconnectButton, toolTip = "Toggles the disconnect button."},
            },

            new ButtonInfo[] { // Movement 
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Disconnect", method = () => Disconnect(), isTogglable = true },
                new ButtonInfo { buttonText = "Platforms", method =() => Global.stickyPlatformsMod(), isTogglable = true},
                new ButtonInfo { buttonText = "SpeedBoost", method =() => Global.SpeedBoost(10,8), isTogglable = true},
                new ButtonInfo { buttonText = "Fly", method =() => Global.fly(), isTogglable = true},
                new ButtonInfo { buttonText = "Frozone", method = () => FrozoneEffect.Frozone(false, false, null, null), isTogglable = true },
                new ButtonInfo { buttonText = "JumpToHigh", method =() => Global.SpeeX(100,80), isTogglable = true},
            },

            new ButtonInfo[] { // Guns 
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Disconnect", method = () => Disconnect(), isTogglable = true },
                new ButtonInfo { buttonText = "TpGun", method =() => Global.TpGun(), isTogglable = true},
                new ButtonInfo { buttonText = "TagGun", method =() => Gamemode.TagGun(), isTogglable = true},
                new ButtonInfo { buttonText = "KickGun", method = () => Overpowered.KickGun(), isTogglable = true },
                new ButtonInfo { buttonText = "ScareGun", method = () => Overpowered.ScareGun(), isTogglable = true },
                new ButtonInfo { buttonText = "ViberateGun", method = () => Overpowered.ViberateGun(), isTogglable = true },
                new ButtonInfo { buttonText = "FreezeRigGun", method = () => Overpowered.FreezeRigGun(false), isTogglable = true },
                new ButtonInfo { buttonText = "WatersplashGun", method = () => Overpowered.WatersplashGun(), isTogglable = true },
                new ButtonInfo { buttonText = "CrashGun", method = () => Overpowered.CrashGun(7,2), isTogglable = true },

            },

            new ButtonInfo[] { // Advantages 
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Disconnect", method = () => Disconnect(), isTogglable = true },
                new ButtonInfo { buttonText = "EditArmLength", method = () => Class3.EditArmLength2.EditArmLength(), isTogglable = true},
                new ButtonInfo { buttonText = "NoSlippyWalls", method = () => Class3.NoSlippyWalls(), isTogglable = true},
                new ButtonInfo { buttonText = "TagAll", method = () => Class3.TagAll(), isTogglable = true },
                new ButtonInfo { buttonText = "TagAura", method = () => Class3.TagAura(), isTogglable = true },
                new ButtonInfo { buttonText = "BoxESP", method =() => Global.BoxESP(), isTogglable = true},
                new ButtonInfo { buttonText = "Ghost Monke", method =() => Global.Ghostmonkey(), isTogglable = true},
                new ButtonInfo { buttonText = "InvisMonke", method = () => {Class4onlyone.isInvisible = !Class4onlyone.isInvisible; Class4onlyone.SetRigVisibility(!Class4onlyone.isInvisible); }, isTogglable = true, toolTip = "." },
            },

            new ButtonInfo[] { // FunMods 
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Disconnect", method = () => Disconnect(), isTogglable = true },
                new ButtonInfo { buttonText = "Punch", method = () => Class3.PunchMod(), isTogglable = true},
                new ButtonInfo { buttonText = "HelicopterMonke", method = () => Class3.HelicopterMonke(), isTogglable = true},
                new ButtonInfo { buttonText = "ReportAll", method = () => X.ReportAll(), isTogglable = true },
                new ButtonInfo { buttonText = "MuteAll", method = () => X.MuteAll(), isTogglable = true },
                new ButtonInfo { buttonText = "NightTime", method = () => Class2.NightTime(), isTogglable = true },
                new ButtonInfo { buttonText = "DayTime", method = () => Class2.DayTime(), isTogglable = true },
                new ButtonInfo { buttonText = "NoonTime", method = () => Class2.NoonTime(), isTogglable = true },
                new ButtonInfo { buttonText = "PeeMod", method = () => Cum.pee(), isTogglable = true },
                new ButtonInfo { buttonText = "rainbowPee", method = () => Cum.rainbowPee(), isTogglable = true },
                new ButtonInfo { buttonText = "WatersplashHands", method = () => Overpowered.WatersplashHands(), isTogglable = true },
                new ButtonInfo { buttonText = "DisableFog", method = () => X.DisableFog(), isTogglable = true },
                new ButtonInfo { buttonText = "EnableFog", method = () => X.EnableFog(), isTogglable = true },
                new ButtonInfo { buttonText = "FakeUnbanSelf", method = () => X.FakeUnbanSelf(), isTogglable = true },
                new ButtonInfo { buttonText = "FixHead", method = () => X.FixHead(), isTogglable = true },
                new ButtonInfo { buttonText = "SpinHead", method = () => X.SpinHead("y"), isTogglable = true },
                new ButtonInfo { buttonText = "HeadBang", method = () => X.HeadBang(), isTogglable = true },
                new ButtonInfo { buttonText = "SidewaysHead", method = () => X.SidewaysHead(), isTogglable = true },
                new ButtonInfo { buttonText = "BackwardsHead", method = () => X.BackwardsHead(), isTogglable = true },
                new ButtonInfo { buttonText = "BrokenNeck", method = () => X.BrokenNeck(), isTogglable = true },
                new ButtonInfo { buttonText = "UpsideDownHead", method = () => X.UpsideDownHead(), isTogglable = true },
                new ButtonInfo { buttonText = "HoldRig", method = () => Class1.HoldRig(), isTogglable = true },
            },

        };
        public static void Disconnect()
        {
            PhotonNetwork.Disconnect();
        }
    }
}

