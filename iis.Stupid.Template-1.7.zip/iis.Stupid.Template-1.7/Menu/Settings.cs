﻿using UnityEngine;
using StupidTemplate.Classes;
using static StupidTemplate.Menu.Main;

namespace StupidTemplate
{
    internal class Settings : MonoBehaviour
    {
        // === Config ===
        private static float hueShiftSpeed = 0.000000000005f; // 10x slower slow fade
        private static float baseHue = 0f;

        // Theme toggle flag
        public static bool useRainbowTheme = false;

        // === Original Light Blue Gradients ===
        private static GradientColorKey[] lightBlueGradient = GetGradient(
            new Color(0.4f, 0.7f, 1f),
            new Color(0.6f, 0.8f, 1f)
        );

        private static GradientColorKey[] lightBlueButtonGradient1 = GetGradient(
            new Color(0.3f, 0.6f, 0.9f),
            new Color(0.4f, 0.7f, 1f)
        );

        private static GradientColorKey[] lightBlueButtonGradient2 = GetGradient(
            new Color(0.6f, 0.8f, 1f),
            new Color(0.7f, 0.9f, 1f)
        );

        // === Gradients ===
        public static ExtGradient backgroundColor = new ExtGradient
        {
            colors = lightBlueGradient,
            isRainbow = false
        };

        public static ExtGradient[] buttonColors = new ExtGradient[]
        {
            new ExtGradient
            {
                colors = lightBlueButtonGradient1,
                isRainbow = false
            },
            new ExtGradient
            {
                colors = lightBlueButtonGradient2,
                isRainbow = false
            }
        };

        public static Color[] textColors = new Color[]
        {
            Color.black,    // default text color
            Color.grey      // when enabled (e.g. fpsCounter == true)
        };

        public static Font currentFont = (Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font);

        public static bool fpsCounter = true;
        public static bool disconnectButton = false;
        public static bool rightHanded = false;
        public static bool disableNotifications = true;

        public static KeyCode keyboardButton = KeyCode.Q;

        public static Vector3 menuSize = new Vector3(0.1f, 1f, 1f);
        public static int buttonsPerPage = 8;

        // === Gradient Generators ===
        public static GradientColorKey[] GetGradient(Color start, Color end)
        {
            return new GradientColorKey[]
            {
                new GradientColorKey(start, 0f),
                new GradientColorKey(end, 1f)
            };
        }

        public static GradientColorKey[] GetSolidGradient(Color color)
        {
            return new GradientColorKey[]
            {
                new GradientColorKey(color, 0f),
                new GradientColorKey(color, 1f)
            };
        }

        public static GradientColorKey[] GetRainbowGradient()
        {
            Color color1 = Color.HSVToRGB(baseHue, 1f, 1f);
            Color color2 = Color.HSVToRGB((baseHue + 0.1f) % 1f, 1f, 1f);

            return new GradientColorKey[]
            {
                new GradientColorKey(color1, 0f),
                new GradientColorKey(color2, 1f)
            };
        }

        // === Runtime Update ===
        public static void UpdateGradients()
        {
            if (!useRainbowTheme) return; // Only update rainbow colors when active

            baseHue += Time.deltaTime * hueShiftSpeed;
            if (baseHue > 1f) baseHue -= 1f;

            if (backgroundColor.isRainbow)
                backgroundColor.colors = GetRainbowGradient();

            for (int i = 0; i < buttonColors.Length; i++)
            {
                if (buttonColors[i].isRainbow)
                    buttonColors[i].colors = GetRainbowGradient();
            }
        }

        // Toggle between light blue and rainbow themes
        public static void ToggleTheme()
        {
            useRainbowTheme = !useRainbowTheme;

            if (useRainbowTheme)
            {
                backgroundColor.isRainbow = true;
                buttonColors[0].isRainbow = true;
                buttonColors[1].isRainbow = true;
                // Initialize to rainbow gradient so UpdateGradients can smoothly start
                backgroundColor.colors = GetRainbowGradient();
                buttonColors[0].colors = GetRainbowGradient();
                buttonColors[1].colors = GetRainbowGradient();
            }
            else
            {
                backgroundColor.isRainbow = false;
                backgroundColor.colors = lightBlueGradient;

                buttonColors[0].isRainbow = false;
                buttonColors[0].colors = lightBlueButtonGradient1;

                buttonColors[1].isRainbow = false;
                buttonColors[1].colors = lightBlueButtonGradient2;
            }
        }

        // Text color helper based on enabled flag
        public static Color GetTextColor(bool enabled)
        {
            return enabled ? textColors[1] : textColors[0];
        }

        // Make sure this runs each frame (attach this script to a GameObject)
        void Update()
        {
            UpdateGradients();
        }
    }
}
